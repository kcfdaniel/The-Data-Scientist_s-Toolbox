require(dplyr)


#Question 1: load the data set and create a data_dplyr and data_base data frame
# load data set
data_base = read.csv("C:/Users/david/OneDrive/Documents/Super Data Science/Case studies/Case study 024/data.csv")
data_dplyr = read.csv("C:/Users/david/OneDrive/Documents/Super Data Science/Case studies/Case study 024/data.csv")



# Qustion 2: format trip_id, user_id and location to be factor varibles
#try to complete using dplyr and base R
data_dplyr = data_dplyr %>% 
  mutate(trip_id = as.factor(trip_id),
          user_id = as.factor(user_id),
          location = as.factor(location))

data_base$trip_id = as.factor(data_base$trip_id)
data_base$user_id = as.factor(data_base$user_id)
data_base$location = as.factor(data_base$location)

# Question 3: what is the longest trip taken?
#try to complete using dplyr and base R
data_dplyr %>% 
  summarise(longest_trip = max(time))
  
max(data_base$time)

#Question 4: what is the longest trip taken by location?
#try to complete using dplyr and base R
data_dplyr %>% 
  group_by(location) %>% 
  summarise(longest_trip = max(time))

aggregate(list(time = data_base$time),
          by = list(location = data_base$location),
          FUN = max)

#Question 5: Add a column with the average time for each location
#try to complete using dplyr and base R and time how long each one takes
start_dplyr = Sys.time()
data_dplyr = data_dplyr %>% 
  group_by(location) %>% 
  mutate(avg_time_location = mean(time))
time_dplyr = Sys.time() - start_dplyr

start_base = Sys.time()
avg_time_location = aggregate(list(avg_time_location = data_base$time),
                              by = list(location = data_base$location),
                              FUN = mean)

data_base = merge(data_base, avg_time_location, by = 'location')
time_base = Sys.time() - start_base

rm(avg_time_location)

#Question 6: create a data frame with only riders who have taken over 100 journeys
data_dplyr_over_100 = data_dplyr %>% 
  group_by(user_id) %>% 
  mutate(number_rides = n()) %>% 
  filter(number_rides > 100)

#Question 7: for riders who have taken over 100 journeys what is the most popular location?
over_100_most_popular_location = data_dplyr %>% 
  group_by(user_id) %>% 
  mutate(number_rides = n()) %>% 
  filter(number_rides > 100) %>% 
  group_by(location) %>% 
  summarise(number_rides = n()) %>% 
  arrange(desc(number_rides))
