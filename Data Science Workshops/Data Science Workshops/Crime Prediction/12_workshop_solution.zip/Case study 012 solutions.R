require(ggplot2)
require(caTools)

#load datasets
data = read.csv("C:/Users/david/OneDrive/Documents/Case studies/Case study 012/data.csv",
                header = FALSE)
variable_names = read.csv("C:/Users/david/OneDrive/Documents/Case studies/Case study 012/variable_names.csv",
                 header = FALSE)

###Question 1: clean names
#drop first 3 characters
variable_names$clean = substr(variable_names$V1, 4, 1000)
#drop characters after colon
variable_names$clean = gsub(':.+', '', variable_names$clean)
#make names of data equal to names data frame
names(data) = variable_names$clean

###Question 2: keep certain variables
model_data = data[,names(data) %in% c('ViolentCrimesPerPop',
                                      'pctUrban',
                                'agePct16t24',
                                'PctUnemployed',
                                'medIncome')]

###Question 3: Check for correaltions of variables
cor(model_data$medIncome, model_data$PctUnemployed)
cor(model_data$ViolentCrimesPerPop, model_data$PctUnemployed)
cor(model_data$ViolentCrimesPerPop, model_data$medIncome)

plot(model_data$PctUnemployed, model_data$medIncome)

###Question 4: split data into training and testing set
set.seed(123)
split = sample.split(model_data$ViolentCrimesPerPop, SplitRatio = 0.8)
training_data = model_data[split,]
testing_data = model_data[!split,]

###Question 5: Build linear regression model
model = lm(formula = ViolentCrimesPerPop ~ agePct16t24 + PctUnemployed + pctUrban, data = training_data)
summary(model)

###Question 6: predict results for testing set
prediction_testing_data = predict(model, newdata = testing_data)

###Quetion 7: calculate out of sample R squared
SSE = sum((prediction_testing_data - testing_data$ViolentCrimesPerPop)^2)
SST = sum((mean(testing_data$ViolentCrimesPerPop) - testing_data$ViolentCrimesPerPop)^2)
test_r2 = 1 - SSE/SST
test_r2