require(cluster)
require(tidyr)
require(dplyr)

# load data set
data = read.csv("C:/Users/david/OneDrive/Documents/Case study 015/data.csv")

#Question 1:  use spread from the tidyr package to make 1 row for each country and
#two columns with GDP per capita and Life expectancy at birth
data = spread(data, key = IndicatorName, value = Value)

#Question 2: update column names to be easier to use
names(data) = c('country_name', 'co2', 'gdp')

#Question 3: remove countries which have missing values
data = na.omit(data)

#Question 4: add normalised columns with mean 0, variance 1
data$gdp_norm = (data$gdp - mean(data$gdp))/sd(data$gdp)
data$co2_norm = (data$co2 - mean(data$co2))/sd(data$co2)

# data$gdp_norm = (data$gdp)
# data$co2_norm = (data$co2)

#Question 5: plot the elbow curve for the normalised variables to see how many clusters to use
data_norm = data[,c('gdp_norm', 'co2_norm')]
elbow_plot = vector()
for (i in 1:15){
  elbow_plot[i] = sum(kmeans(data_norm, i)$withinss)
}
plot(elbow_plot, type = 'b')

#Question 6:create kmeans clusters
set.seed(123)
kmeans = kmeans(data_norm, 4, iter.max = 500, nstart = 10)

#Question 7: plot kmeans clusters on graph
clusplot(data_norm,
         kmeans$cluster,
         lines = 0,
         shade = T,
         color = T,
         labels = 0,
         plotchar = F,
         span = T,
         xlab = 'gdp',
         ylab = 'co2')

#Question 8: calculate average gdp, average co2 and number of countries by cluster
data$cluster = kmeans$cluster
data_summary = data %>% 
  group_by(cluster) %>% 
  summarise(avg_gdp = mean(gdp),
            avg_co2 = mean(co2),
            number_countries = n())
View(data %>% arrange(cluster))
