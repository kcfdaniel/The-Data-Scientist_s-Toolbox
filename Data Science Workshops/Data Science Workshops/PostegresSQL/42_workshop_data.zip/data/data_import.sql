COPY Category    FROM 'C:\Users\daniel\Super Data Science\Case Study\042 - SQL\data\Category.csv'    DELIMITER ',' CSV HEADER;
COPY Branch      FROM 'C:\Users\daniel\Super Data Science\Case Study\042 - SQL\data\Branch.csv'      DELIMITER ',' CSV HEADER;
COPY Customer    FROM 'C:\Users\daniel\Super Data Science\Case Study\042 - SQL\data\Customer.csv'    DELIMITER ',' CSV HEADER;
COPY SalesRep    FROM 'C:\Users\daniel\Super Data Science\Case Study\042 - SQL\data\SalesRep.csv'    DELIMITER ',' CSV HEADER;
COPY Orders      FROM 'C:\Users\daniel\Super Data Science\Case Study\042 - SQL\data\Orders.csv'      DELIMITER ',' CSV HEADER;
COPY Product     FROM 'C:\Users\daniel\Super Data Science\Case Study\042 - SQL\data\Product.csv'     DELIMITER ',' CSV HEADER;
COPY OrderDetail FROM 'C:\Users\daniel\Super Data Science\Case Study\042 - SQL\data\OrderDetail.csv' DELIMITER ',' CSV HEADER;